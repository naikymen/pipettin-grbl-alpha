                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1321221
Parametric Female/Female Pin Connector by lilo_booter is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

This thing provides the ability to generate connector caps for male pins, such as the GPIO connector on a Raspberry pi, uln2003 stepper motor driver boards and probably others.

You can use this link to configure customised variants:

http://openjscad.org/#http://www.geminidev.be/3d/gpio2.jscad

Note that the generated STL will need to be repaired using netfabb or similar for some slicers to handle. 

# Print Settings

Printer Brand: MakerGear
Printer: M2
Rafts: Doesn't Matter
Supports: No
Resolution: 0.25

Notes: 
Print as oriented - rotating it such that the pins run from top to bottom results in a poor print. 

All default variables are multiples of 0.25mm, hence slicing it at 0.25 provides the best results. Your own customisations may change this if you want.

I would suggest printing slow and trying to remove any oozed filament before the print starts as everything is quite delicate and erroneously extruded filament could block the hole or misshape the print.